package Parking;

import java.util.Random;

/**
 * Coche que intenta entrar al aparcamiento
 * Implementa Runnable para ejecutarse en un hilo independiente
 */
public class Coche implements Runnable {
    private final Aparcamiento aparcamiento;
    private final String nombre;
    private final Random random = new Random();

    /**
     * @param aparcamiento referencia compartida al aparcamiento
     * @param nombre nombre identificativo del coche (ejemplo: "Coche-1")
     */
    public Coche(Aparcamiento aparcamiento, String nombre) {
        this.aparcamiento = aparcamiento;
        this.nombre = nombre;
    }

    @Override
    public void run() {
        aparcamiento.entrar(nombre);
        // Permanecer aparcado entre 1 y 4 segundos
        int millis = 1000 + random.nextInt(3000); // [1000, 4000)
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.printf("%s fue interrumpido mientras estaba aparcado.%n", nombre);
        }
        aparcamiento.salir(nombre);
    }
}
