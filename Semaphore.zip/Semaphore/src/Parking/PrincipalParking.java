package Parking;

import java.util.ArrayList;
import java.util.List;

/**
 * Punto de entrada: crea el aparcamiento, los 7 coches y lanza los hilos.
 */
public class PrincipalParking {
    public static void main(String[] args) {
        final int PLAZAS = 3;
        final int COCHES = 7;

        Aparcamiento parking = new Aparcamiento(PLAZAS);
        List<Thread> hilos = new ArrayList<>();

        for (int i = 1; i <= COCHES; i++) {
            Thread t = new Thread(new Coche(parking, "Coche-" + i));
            hilos.add(t);
            t.start();
        }

        // Espera a que terminen todos los hilos para cerrar el programa de forma ordenada.
        for (Thread t : hilos) {
            try {
                t.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("La espera del hilo fue interrumpida.");
            }
        }

        System.out.println("Simulación finalizada.");
    }
}
