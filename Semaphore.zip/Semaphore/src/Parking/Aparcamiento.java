package Parking;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Representa un aparcamiento con un número limitado de plazas
 * Semaphore controla el acceso
 */
public class Aparcamiento {
    // Semáforo con el número de plazas disponibles
    private final Semaphore semaforo;
    // Plazas ocupadas
    private final AtomicInteger plazasOcupadas = new AtomicInteger(0);
    private final int capacidad;

    /**
     * Crea un aparcamiento con capacidad 'capacidad' plazas
     * @param capacidad número de plazas (3)
     */
    public Aparcamiento(int capacidad) {
        this.capacidad = capacidad;
        this.semaforo = new Semaphore(capacidad, true);
    }

    /**
     * Intenta entrar al aparcamiento (bloquea si no hay plazas)
     * @param nombreCoche identificador del coche (hilo)
     */
    public void entrar(String nombreCoche) {
        // Mensaje: el coche va a intentar entrar
        System.out.printf("%s intenta entrar...%n", nombreCoche);

        try {
            // Adquiere un permiso (bloquea si no hay plazas)
            semaforo.acquire();
            int ocupadas = plazasOcupadas.incrementAndGet();
            System.out.printf("%s ha entrado. Plazas ocupadas: %d/%d%n",
                    nombreCoche, ocupadas, capacidad);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.printf("%s fue interrumpido mientras esperaba entrar.%n", nombreCoche);
        }
    }

    /**
     * Sale del aparcamiento y libera.
     * @param nombreCoche identificador del coche (hilo)
     */
    public void salir(String nombreCoche) {
        // Primero liberamos el estado visible, luego el permiso del semáforo.
        int ocupadas = plazasOcupadas.decrementAndGet();
        System.out.printf("%s ha salido. Plazas ocupadas: %d/%d%n",
                nombreCoche, ocupadas, capacidad);
        semaforo.release();
    }
}
